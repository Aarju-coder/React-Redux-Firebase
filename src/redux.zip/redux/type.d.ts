export interface User {
    email: string;
    id: string;
    createdAt: any;
  }
  export interface SignInData {
    email: string;
    password: string;
  }
export interface AuthState {
    user: User | null;
    authenticated: boolean;
    loading: boolean;
    error: string;
    needVerification: boolean;
    success: string;
  }

export type RootState = {
    auth: AuthState
}