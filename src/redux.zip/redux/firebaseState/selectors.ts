import { RootState } from "../type"

export const currentAuth = (state: RootState) =>
  state.auth