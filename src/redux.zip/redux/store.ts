//store.ts
import {firebaseReduce} from "./firebaseState/slice";
import {
  configureStore,
  getDefaultMiddleware,
  ThunkAction,
  Action,
} from "@reduxjs/toolkit";
import logger from "redux-logger";
import { RootState } from "./type";

const middleware = [...getDefaultMiddleware(), logger];

export const store = configureStore({
  reducer: {
    auth:firebaseReduce,
  },
  middleware,
});

export type AppThunk = ThunkAction<void, RootState, unknown, Action<string>>;
